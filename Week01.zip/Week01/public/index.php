<?php
  $names = array("Erica", "Garritt", "Joe", "Emily", "Will", "Morgan", "Dayna", "Bryan", "Dave", "Marcus");

  $randomNumber = rand(0, 20);

  echo "Random Number: " . $randomNumber . "! ";

    if ($randomNumber == 0) {
      echo "Hello " . $names[0];
    }
    if ($randomNumber == 1) {
      echo "Hello " . $names[1];
    }
    if ($randomNumber == 2) {
      echo "Hello " . $names[2];
    }
    if ($randomNumber == 3) {
      echo "Hello " . $names[3];
    }
    if ($randomNumber == 4) {
      echo "Hello " . $names[4];
    }
    if ($randomNumber == 5) {
      echo "Hello " . $names[5];
    }
    if ($randomNumber == 6) {
      echo "Hello " . $names[6];
    }
    if ($randomNumber == 7) {
      echo "Hello " . $names[7];
    }
    if ($randomNumber == 8) {
      echo "Hello " . $names[8];
    }
    if ($randomNumber == 9) {
      echo "Hello " . $names[9];
    }
    else if($randomNumber > 9) {
      echo "Name List: " .  $names[0] . ", " . $names[1] . ", " . $names[2] . ", " . $names[3] . ", " . $names[4] . ", " . $names[5] . ", " . $names[6] . ", " . $names[7] . ", " . $names[8] . ", " . $names[9];
    }

?>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Week 1</title>
  </head>
  <body>
    
  </body>
</html>
