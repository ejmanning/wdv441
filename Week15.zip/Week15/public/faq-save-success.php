<?php
session_start();
require_once('../tpl/faq-save-success.tpl.php');
?>
