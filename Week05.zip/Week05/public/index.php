<?php
require_once('../inc/NewsArticles.class.php');

$newsArticle = new NewsArticles();
$articleList = $newsArticle->getList();

?>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <style>
       body {
          background-color: #b5f1ff;
       }

       table {
           background-color: white;
       }

       table,
       th,
       td {
           border: 1px solid black;
       }

       th,
       td {
           padding: 15px;
       }

       th {
           text-align: left;
       }

       table {
           border-spacing: 5px;
           margin: auto;
       }

       header {
           text-align: center;
           font-size: 2em;
           color: white;
           text-shadow: -1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000, 1px 1px 0 #000;

       }

       td a {
           text-decoration:none;
           font-size: 20px;
       }

       .button {
           background-color: white;
           color: black;
           border: 2px solid black;
       }

       .button:hover {
           background-color: gray;
           color: white;
       }
   </style>
</head>
<body>
    <header>
        <h2>News Articles</h2>
    </header>

<table>
<tr >
    <td class="button"><a href="article-edit.php"?>Add new article</a></td>
</tr>

</table><br>

    <table>

        <tr>
            <th>Article Title</th>
            <th>Article Content</th>
            <th>Article Author</th>
            <th>Article Date</th>
            <th colspan="2">Options</th>

        </tr>

        <?php foreach ($articleList as $articleInfo) { ?>
        <tr>
            <td>
                <?php echo $articleInfo['articleTitle'];?>
            </td>

            <td>
                <?php echo $articleInfo['articleContent'];?>
            </td>

            <td>
                <?php echo $articleInfo['articleAuthor'];?>
            </td>

            <td>
                <?php echo $articleInfo['articleDate'];?>
            </td>

            <td class="button">
                <a href="article-edit.php?articleID=<?php echo $articleInfo['articleID'];?>">Edit</a>
            </td>
            <td class="button">
                <a href="article-view.php?articleID=<?php echo $articleInfo['articleID'];?>">View</a>
            </td>
        </tr>

        <?php } ?>
    </table>

</body>
</html>
