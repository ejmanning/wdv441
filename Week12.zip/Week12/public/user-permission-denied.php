<?php
session_start();
require_once('../tpl/user-permission-denied.tpl.php');
?>
