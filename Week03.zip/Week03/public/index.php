<?php
function loadUserInformation($tableData) {
  return $tableData;
}

// save
function saveInput($table, $inputArray) {
  return $inputArray;
}

// validate
function validateInput($inputArray) {
  return $inputArray;
}


?>
