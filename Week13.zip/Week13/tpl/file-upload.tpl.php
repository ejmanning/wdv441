<html>
    <body>
        <form action="<?php echo $_SERVER['SCRIPT_NAME']; ?>" method="post" enctype="multipart/form-data">
            upload file: <input type="file" name="upload_file"/><br>
            <input type="submit" name="Save" value="Save"/>
        </form>        
    </body>
</html>