<html>
    <body>
        yay!<br>
        <a href="user-list.php">Back to List</a>
    </body>    
</html>