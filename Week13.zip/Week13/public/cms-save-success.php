<html>
    <body>
        yay!<br>
        <a href="cms-list.php">Back to List</a>
    </body>    
</html>